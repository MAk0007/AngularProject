export interface Product{
    Name : string;
    Price : number;
    Desc ?: string;
    ProductPath : string;     
}