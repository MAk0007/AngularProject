import { CartService } from './../../services/cart.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  Shoppingcart : Array<any>;
  totalCartAmount : number =0;
  constructor(private cs : CartService) {
    
   }

  ngOnInit(): void {
    this.cs.getCart().subscribe( cart => {
      this.Shoppingcart = cart.map( x => {
        return {
          id: x.payload.doc.id,
          ...x.payload.doc.data() as {}
        }
      })
      this.reCalcTotalCartAmount();
      console.log(this.Shoppingcart);
    });
    

  }
  deleteCart(index){
    this.cs.deleteDocFromCart(this.Shoppingcart[index].id);
    // this.reCalcTotalCartAmount();

  }

  updateCart(index){
    this.cs.updateDocFromCart(this.Shoppingcart[index].id,this.Shoppingcart[index].amount );
    // this.reCalcTotalCartAmount();
  }

 reCalcTotalCartAmount(){
   this.totalCartAmount = 0;
   console.log(this.Shoppingcart);
   this.Shoppingcart.map( x => {
    this.totalCartAmount += (x.amount*x.price);
    // console.log(x);
   })
  //  console.log(this.totalCartAmount);
 }

}
