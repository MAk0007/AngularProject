import { Router } from '@angular/router';
import { AuthService } from './../../services/auth.service';
import { CartService } from './../../services/cart.service';
import { ProductsService } from '../../services/products.service';
import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/interface/products.interface';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  Products : Array<any> =[
    // {Name: "Shoe", Price : 500, Desc: "footwear", ProductPath: "assets/Pics/Shoe.jpg"},
    // {Name: "Banana", Price : 30, Desc: "fruits", ProductPath: "assets/Pics/Banana.jpg"},
    // {Name: "Potato", Price : 50, Desc: "vegetables", ProductPath: "assets/Pics/Potato.jpg"},
    // {Name: "Shirt", Price : 700, Desc: "clothing", ProductPath: "assets/Pics/Shirt.jpg"},
  ];

  add : number = -1;

  constructor(private ps : ProductsService, private cart : CartService,
     private as : AuthService, private router : Router) { 
    
  }

  ngOnInit(): void {
    this.ps.getAllProducts().subscribe(
      data => this.Products = data 
    )
  }
  addToCart(index){
    // console.log("added",this.Products[index]);
    if(this.as.userId){
    this.add = +index;
  }else{
    this.router.navigate(['/login'])
  }
    // console.log(this.add);
  }

  buy(amount){
    let selectedProduct = this.Products[this.add];
    let data = {
      name: selectedProduct.Name,
      price: selectedProduct.Price,
      amount: +amount
    }
    // console.log(data);
    this.cart.addToCart(data)
      .then( () => this.add = -1)
      .catch(
        // err => console.log(err)
        );
  }
}
