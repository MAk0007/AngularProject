import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor(private as : AuthService , private router : Router) { }

  isOpen : boolean = false;
  isUser : boolean =false;

  ngOnInit(): void {
    this.as.user.subscribe( user => {
      if(user){
        this.isUser =true;
        this.as.userId = user.uid;
        console.log(this.isUser);
      }else{
        this.isUser = false;
        this.as.userId = '';
        console.log(this.isUser);
      }
    })
  }

  toggleNavBar(){
    this.isOpen = !this.isOpen;
  }

  logout(){
    console.log("logout successful.!");
    this.as.logout();
    // this.router.navigate(['/login']);
  }
}
