import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginErrorMsg : string = '';
  constructor(private as : AuthService,private router : Router) { }

  ngOnInit(): void {
  }

  loginfn(loginForm){
    console.log(loginForm.value.email);
    console.log(loginForm.value.password);

    this.as.login(loginForm.value.email,loginForm.value.password)
      .then( data => {
        console.log(data);
        this.router.navigate(['/']);
        this.loginErrorMsg = '';
      })
      .catch( err => {
        console.log(err);
        this.loginErrorMsg = err;
      })

  }

}
