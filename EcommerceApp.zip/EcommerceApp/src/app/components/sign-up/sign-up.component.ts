import { Router, RouterModule } from '@angular/router';
import { UserService } from './../../services/user.service';
import { AuthService } from './../../services/auth.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  errorMsg : string ="";
  constructor(private as : AuthService, private user : UserService, private router : Router) { }

  ngOnInit(): void {
  }
  signup(form){
    console.log(form.value.email);
    console.log(form.value.password);

    this.as.signup(form.value.email,form.value.password)
      .then( data =>{
        this.user.addNewUser(data.user.uid,form.value.name,form.value.address);
        this.errorMsg = '';
        this.router.navigate(['/']);
      })
      .catch( err =>{ 
        console.log(err);
        this.errorMsg =err;
      });
  }

}
