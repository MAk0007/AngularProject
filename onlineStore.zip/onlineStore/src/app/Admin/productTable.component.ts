import { Router, RouterModule } from '@angular/router';
import { productRepository } from './../../Model/product.repository';
import { Product } from './../../Model/product.model';
import { Component } from '@angular/core';

@Component({
    templateUrl: "productTable.component.html",
})
export class ProductTableComponent {
    constructor(private repository: productRepository, private router: Router) {

    }

    getProducts() : Product[]{
        return this.repository.getProducts();
    }

    deleteProduct(id : number) {
        this.repository.deleteProduct(id);
    }
    
    //adding  a method to get the url straight
    getURLforEditProduct(url: any,id: number) 
    // : any 
    {
        this.router.navigate([url, id]).then( (e) => {
            if (e) {
              console.log("Navigation to edit product page successful!");
            } else {
              console.log("Navigation to edit product page has failed!");
            }
          });
        // return ['admin/main/products/edit/'+id]
    }

}