import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import {Injectable} from '@angular/core';
import { AuthService } from './../../Model/auth.service';

@Injectable()
export class AuthGuard{
    constructor(private route: Router,
        private auth: AuthService){

    }

    canActivate(route : ActivatedRouteSnapshot,
        state : RouterStateSnapshot) : boolean{
            if(!this.auth.authenticated){
                this.route.navigateByUrl("/Admin/auth");
                return false;
            }
            return true;
        }

}
