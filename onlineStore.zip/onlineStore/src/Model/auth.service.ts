import {Injectable} from '@angular/core';
import { RestDataSource } from './rest.datasource';
import { Observable } from 'rxjs';

@Injectable()
export class AuthService{
    constructor( private datasource : RestDataSource){

    }

    /* 3 methods*/
    //Authentication method will receive User/Admin credentials
    authenticate(username: string, password: string) : Observable<boolean>{
        return this.datasource.authenticate(username,password);
    }

    //Authenticated property Getter only
    get authenticated() : boolean{
        return this.datasource.auth_token != null;
    }

    //clear it will remove the token from Data Source
    clear(){
        this.datasource.auth_token = null;
    }
    
}