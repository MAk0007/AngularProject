import { Order } from './order.model';
import { Product } from './product.model';
import { Cart } from './../app/store/cart.model';
import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from 'rxjs';
import { map } from "rxjs/operators";

const PROTOCOL = "http";
const PORT = 4210;

@Injectable()
export class RestDataSource{
    baseUrl : string ;
    auth_token : string ;

    constructor(private http : HttpClient){
        this.baseUrl = 
            `${PROTOCOL}://${location.hostname}:${PORT}/`;
    }

    getProducts() : Observable<Product[]>{
        return this.http.get<Product[]>(this.baseUrl + "products");
    }

    saveOrder(order : Order) : Observable<Order>{
        return this.http.post<Order>(this.baseUrl + "orders" , order);
    }

    authenticate(user : string, pass : string) : Observable<boolean>{
        return this.http.post<any>(this.baseUrl + "login", 
        {
            name : user,
            password : pass
        }).pipe(map(response =>{
            console.log("response.token: ",response.token);
            this.auth_token = 
            response.success ? response.token : null ;
    console.log("this.auth_token: ",this.auth_token);
            return response.success;
        }));
    }

    //dealing with products and returning observable<products>

    saveProduct(product : Product) : Observable<Product>
    {
        return this.http.post<Product>(this.baseUrl + "products", product, this.getOptions());
    }

    updateProduct(product) : Observable<Product>{
        console.log(JSON.stringify(product));
        return this.http.put<Product>(
            `${this.baseUrl}products/${product.id}`, product , this.getOptions());
    } 

    //delete product
    deleteProduct(id : number) : Observable<Product> {
        return this.http.delete<Product>
        (`${this.baseUrl}products/${id}`, this.getOptions());
    }

    private getOptions(){
        console.log("auth_token from getOptions: ",`Bearer<${this.auth_token}>`);
               
        var tokenReturn = {
            headers : new HttpHeaders
            ({
                "authorization": `Bearer<${this.auth_token}>`
            })
        }
         console.log("tokenReturn.headers.get('authorization'): ",tokenReturn.headers.get("authorization"));
        //   headers["authorization"]);
        return tokenReturn;
    }

    //Orders Get, Delete, Update
    getOrder() : Observable<Order[]>{
        return this.http.get<Order[]>
        (this.baseUrl + 'orders', this.getOptions());
    }

    //update Order
    updateOrder(order : Order) : Observable<Order>{
        return this.http.put<Order>(
            `${this.baseUrl}orders/${order.id}` , this.getOptions
        );
    }

    //delete order
    deleteOrder(id: number) : Observable<Order>
    {
        return this.http.delete<Order>
        (`${this.baseUrl}orders/${id}`, this.getOptions());
    }
}
