const jwt = require("jsonwebtoken");

const APP_SECRET = "myappsecret";
const USERNAME = "admin";
const PASSWORD = "secret";

module.exports = function(req, res, next){
    if((req.url == "/api.login" || req.url == "/login") 
            && req.method == "POST"){
        if(req.body != null && req.body.name == USERNAME
                && req.body.password== PASSWORD){
                let token = jwt.sign({ data: USERNAME, expireIn: "1h"}, APP_SECRET);
                        res.json({ success: true, token: token});
                        console.log("inside module exports fn() inside if ", token);
        }else{
                res.json({success: false});
        }
        res.end();
        return;
    }else if ((((req.url.startsWith("/api/products")
            || req.url.startsWith("/products"))
        || (req.url.statesWith("/api/categories")
            || req.url.startsWith("/categories"))) && req.method != "GET")
        || ((req.url.startsWith("/api/orders")
            || req.url.startsWith("/orders")) && req.method != "POST")){
                console.log("req: ",req.headers["authorization"]);
            let token = req.
            // header.GET("authorization");
             headers["authorization"];
                console.log("token raw: ",token);
            if(token != null && token.startsWith("Bearer<")){
                console.log("token before: ",token);
                token = token = token.substring(7, token.length -1);
                console.log("token after: ",token);
                try{
                    jwt.verify(token,APP_SECRET);
                    next();
                    return;
                }catch(err){}
            }
            res.statusCode = 401;
            res.end();
            return;
        }
        next();
}



// module.exports = router ;