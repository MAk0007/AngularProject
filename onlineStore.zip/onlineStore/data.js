module.exports = function(){
    return {
        products: [
            {id:1, name:"Lace up shoe", category:"Category 1", description:"Sneaker Shoe (Category 1)", price:"100"},
            {id:2, name:"T-shirt", category:"Category 1", description:"T-shirt HQ (Category 1)", price:"200"},
            {id:3, name:"Cooler", category:"Category 1", description:"Cooler (Category 1)", price:"300"},
            {id:4, name:"Graphic T-shirt", category:"Category 1", description:"Graphic T-shirt (Category 1)", price:"90"},
            {id:5, name:"Lace up shoe", category:"Category 2", description:"Sneaker Shoe (Category 2)", price:"200"},
            {id:6, name:"T-shirt", category:"Category 2", description:"T-shirt HQ (Category 1)", price:"400"},
            {id:7, name:"Cooler", category:"Category 2", description:"Cooler (Category 2)", price:"600"},
            {id:8, name:"Graphic T-shirt", category:"Category 2", description:"Graphic T-shirt (Category 2)", price:"180"},
            {id:9, name:"Cooler", category:"Category 3", description:"Cooler (Category 3)", price:"350"}

        ],
        orders:[ ]
    }
}

// module.exports = router ;