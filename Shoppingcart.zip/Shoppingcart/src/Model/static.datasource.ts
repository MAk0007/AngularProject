import { Order } from './order.model';
import { Product } from './product.model';
import { Observable, from } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable()
export class StaticDataSource{
    private product: Product[] = [
        new Product(1,"Lace up shoe", "Category 1", "Sneaker Shoe (Category 1)", 100),
        new Product(2,"T-shirt", "Category 1", "T-shirt HQ (Category 1)", 90),
        new Product(3,"Cooler", "Category 1", "Cooler (Category 1)", 99),
        new Product(4,"Graphic T-shirt", "Category 1", "Graphic T-shirt (Category 1)", 60),
        new Product(5,"Lace up shoe", "Category 2", "Sneaker Shoe (Category 2)", 200),
        new Product(6,"T-shirt", "Category 2", "T-shirt HQ (Category 2)", 180),
        new Product(7,"Cooler", "Category 2", "Cooler (Category 2)", 200),
        new Product(8,"Graphic T-shirt", "Category 2", "Graphic T-shirt (Category 2)", 120),
        new Product(8,"T-shirt c3", "Category 3", "Graphic T-shirt (Category 3)", 120),
    ];

    getProducts() : Observable<Product[]>{
        return from([this.product]);
    }

    saveOrder(order : Order) : Observable<Order>{
        console.log(JSON.stringify(order));
        return from([order])
    }

}
