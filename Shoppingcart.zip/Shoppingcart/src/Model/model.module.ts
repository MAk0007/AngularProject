import { OrderRepository } from './order.repository';
import { Order } from './order.model';
import { Cart } from './../app/store/cart.model';
import { NgModule } from '@angular/core';
import { StaticDataSource } from './static.datasource';
import { productRepository } from './product.repository';
// import {}

@NgModule({
    providers : [ productRepository, StaticDataSource, Cart ,
        Order, OrderRepository]
})

export class ModelModule{
    
}