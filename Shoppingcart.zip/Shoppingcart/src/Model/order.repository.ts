import { Observable } from 'rxjs';
import { StaticDataSource } from './static.datasource';
import { Order } from './order.model';
import { Injectable } from '@angular/core';

@Injectable()
export class OrderRepository{
    
    private orders : Order[] =[];
    constructor(private dataSource : StaticDataSource){

    }

    // this file handles two things 
    //first is ds which has products its self
    //secondly order which will get product from this DS

    getOrders() : Order[]{
       return this.orders; 
    }

    saveOrder(order : Order) : Observable<Order>{
        return this.dataSource.saveOrder(order);
    }
}